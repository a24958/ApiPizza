namespace api.Models;

public class Pedidos {
    public int Id { get; set; }
    public double Price { get; set; }
    public List<Pizza>? Pizzas { get; set; }
    public Usuarios? User { get; set; }

}