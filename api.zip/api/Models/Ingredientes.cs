namespace api.Models;

public class Ingredientes {

    public int Id { get; set; }
    public string? Name { get; set; }
    public bool IsVegan { get; set; }
}