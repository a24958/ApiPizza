using api.Models;

namespace api.Data;

public class PedidosData : IPedidosData {
    static List<Pedidos> Orders { get; }
    static List<Ingredientes> ingredients = new List<Ingredientes> 
    {
        new Ingredientes { Id = 1, Name = "Queso", IsVegan = false },
        new Ingredientes { Id = 2, Name = "Tomate", IsVegan = true },
        new Ingredientes { Id = 3, Name = "Jamon Serrano", IsVegan = false },
        new Ingredientes { Id = 4, Name = "Albahaca", IsVegan = true },
    };
    static List<Pizza> Pizzas = new List<Pizza> {
        new Pizza { 
                Id = 1, 
                Name = "Classic Italian", 
                IsGlutenFree = false, 
                Ingredients = new List<Ingredientes> {ingredients[0], ingredients[1], ingredients[3]} 
            },
            new Pizza { 
                Id = 2, 
                Name = "Veggie", 
                IsGlutenFree = true, 
                Ingredients = new List<Ingredientes> {ingredients[1], ingredients[3]}
            }
    };

    static List<Usuarios> users = new List<Usuarios>
    {
        new Usuarios{
                Id = 1,
                Name = "Antonio",
                Surname = "Martínez",
                Address = "C/ Violeta Parra",
                Telephone = 123456789
            },
            new Usuarios{
                Id = 2,
                Name = "Aarón",
                Surname = "Ballestín",
                Address = "C/ Madre Rafols",
                Telephone = 987654321
            }
    };
    static int nextId = 3;

    static PedidosData() 
    {
        Orders = new List<Pedidos> 
        {
            new Pedidos {Id = 1, Price = 15.80, Pizzas = new List<Pizza> {Pizzas[0]}, User = users[0]},
            new Pedidos {Id = 2, Price = 32.75, Pizzas = new List<Pizza> {Pizzas[0], Pizzas[1]}, User = users[1]}
        };
    }

    public List<Pedidos> GetAll() => Orders;

    public Pedidos? Get(int id) => Orders.FirstOrDefault(p => p.Id == id);

    public List<Pizza>? GetPizzas(int id) => Orders.FirstOrDefault(o => o.Id == id).Pizzas;

    public Usuarios? GetUsuarios(int id) => Orders.FirstOrDefault(o => o.Id == id).User;

    public void Add(Pedidos order)
    {
        order.Id = nextId++;
        Orders.Add(order);
    }

    public void Delete(int id)
    {
        var order = Get(id);
        if(order is null)
            return;

        Orders.Remove(order);
    }

    public void Update(Pedidos order)
    {
        var index = Orders.FindIndex(o => o.Id == order.Id);
        if(index == -1)
            return;

        Orders[index] = order;
    }
}