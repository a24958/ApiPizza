using api.Models;

namespace api.Data;

public class UsuariosData : IUsusariosData {
    static List<Usuarios> Users { get; }
    static int nextId = 3;
    
    static UsuariosData ()
    {
        Users = new List<Usuarios>
        {
            new Usuarios{
                Id = 1,
                Name = "Antonio",
                Surname = "Martínez",
                Address = "C/ Violeta Parra",
                Telephone = 123456789
            },
            new Usuarios{
                Id = 2,
                Name = "Aarón",
                Surname = "Ballestín",
                Address = "C/ Madre Rafols",
                Telephone = 987654321
            }
        };
    }

    public List<Usuarios> GetAll() => Users;

    public Usuarios? Get(int id) => Users.FirstOrDefault(p => p.Id == id);

    public void Add(Usuarios user)
    {
        user.Id = nextId++;
        Users.Add(user);
    }

    public void Delete(int id)
    {
        var user = Get(id);
        if(user is null)
            return;

        Users.Remove(user);
    }

    public void Update(Usuarios user)
    {
        var index = Users.FindIndex(u => u.Id == user.Id);
        if(index == -1)
            return;

        Users[index] = user;
    }
}