﻿using api.Models;

namespace api.Data;

public class PizzaData : IPizzaData {
    static List<Pizza> Pizzas { get; }
    static int nextId = 3;
    static List<Ingredientes> ingredients = new List<Ingredientes>
    {
        new Ingredientes { Id = 1, Name = "Queso", IsVegan = false },
        new Ingredientes { Id = 2, Name = "Tomate", IsVegan = true },
        new Ingredientes { Id = 3, Name = "Jamon Serrano", IsVegan = false },
        new Ingredientes { Id = 4, Name = "Albahaca", IsVegan = true },
    };
    static PizzaData ()
    {
        Pizzas = new List<Pizza>
        {
            new Pizza {
                Id = 1,
                Name = "Classic Italian",
                IsGlutenFree = false,
                Ingredients = new List<Ingredientes> {ingredients[0], ingredients[1], ingredients[3]}
            },
            new Pizza {
                Id = 2,
                Name = "Veggie",
                IsGlutenFree = true,
                Ingredients = new List<Ingredientes> {ingredients[1], ingredients[3]}
            }
        };
    }

    public List<Pizza> GetAll() => Pizzas;

    public Pizza? Get(int id) => Pizzas.FirstOrDefault(p => p.Id == id);

    public List<Ingredientes>? GetIngredients(int id) => Pizzas.FirstOrDefault(p => p.Id == id).Ingredients;

    public void Add(Pizza pizza)
    {
        pizza.Id = nextId++;
        Pizzas.Add(pizza);
    }

    public void Delete(int id)
    {
        var pizza = Get(id);
        if(pizza is null)
            return;

        Pizzas.Remove(pizza);
    }

    public void Update(int id, Pizza pizza)
    {
        var index = Pizzas.FindIndex(p => p.Id == pizza.Id);
        if(index == -1)
            return;

        Pizzas[index] = pizza;
    }
}