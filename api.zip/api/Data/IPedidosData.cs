using api.Models;

namespace api.Data;

public interface IPedidosData
{
    List<Pedidos> GetAll();
    Pedidos? Get(int id);
    List<Pizza>? GetPizzas(int id);
    Usuarios? GetUsuarios(int id);
    void Add(Pedidos order);
    void Delete(int id);
    void Update(Pedidos order);
}