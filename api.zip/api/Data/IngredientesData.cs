using api.Models;

namespace api.Data;

public class IngredientesData : IIngredientesData {
    static List<Ingredientes> Ingredients { get; }
    static int nextId = 5;

    static IngredientesData() 
    {
        Ingredients = new List<Ingredientes> 
        {
            new Ingredientes { Id = 1, Name = "Queso", IsVegan = false },
            new Ingredientes { Id = 2, Name = "Tomate", IsVegan = true },
            new Ingredientes { Id = 3, Name = "Jamon Serrano", IsVegan = false },
            new Ingredientes { Id = 4, Name = "Albahaca", IsVegan = true },
        };
    }

    public List<Ingredientes> GetAll() => Ingredients;

    public Ingredientes? Get(int id) => Ingredients.FirstOrDefault(p => p.Id == id);

    public void Add(Ingredientes ingredient)
    {
        ingredient.Id = nextId++;
        Ingredients.Add(ingredient);
    }

    public void Delete(int id)
    {
        var ingredient = Get(id);
        if(ingredient is null)
            return;

        Ingredients.Remove(ingredient);
    }

    public void Update(Ingredientes ingredient)
    {
        var index = Ingredients.FindIndex(p => p.Id == ingredient.Id);
        if(index == -1)
            return;

        Ingredients[index] = ingredient;
    }
}