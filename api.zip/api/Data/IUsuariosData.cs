using api.Models;

namespace api.Data;

public interface IUsusariosData

{
    List<Usuarios> GetAll();
    Usuarios? Get(int id);
    void Add(Usuarios usuarios);
    void Delete(int id);
    void Update(Usuarios usuarios);
}