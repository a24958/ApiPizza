using api.Models;

namespace api.Data;

public interface IIngredientesData
{
    List<Ingredientes> GetAll();
    Ingredientes? Get(int id);
    void Add(Ingredientes ingredient);
    void Delete(int id);
    void Update(Ingredientes ingredient);
}