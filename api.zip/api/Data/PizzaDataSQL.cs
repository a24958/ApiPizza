using System.Data.SqlClient;
using api.Models;

namespace api.Data;

public class PizzaDataSQL : IPizzaData
{
    private readonly string _connectionString;

    public PizzaDataSQL(string connectionString)
    {
        _connectionString = connectionString;
    }

    public List<Pizza> GetAll()
    {
        List<Pizza> pizzas = new List<Pizza> { };

        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();

            var sqlString = "SELECT P.Id AS PizzaId, P.Name AS PizzaName, P.IsGlutenFree, I.Id AS IngredientId, I.Name AS IngredientName, I.IsVegan FROM Pizza P JOIN PizzaIngredientes PI ON P.Id = PI.PizzaId JOIN Ingredientes I ON PI.IngredienteId = I.Id";
            var command = new SqlCommand(sqlString, connection);

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    int pizzaId = (int)reader["PizzaId"];
                    var pizza = pizzas.FirstOrDefault(p => p.Id == pizzaId);

                    if (pizza == null)
                    {
                        pizza = new Pizza
                        {
                            Id = pizzaId,
                            Name = reader["PizzaName"].ToString(),
                            IsGlutenFree = (bool)reader["IsGlutenFree"],
                            Ingredients = new List<Ingredientes>()
                        };
                        pizzas.Add(pizza);
                    }

                    pizza.Ingredients.Add(
                        new Ingredientes
                        {
                            Id = (int)reader["IngredientId"],
                            Name = reader["IngredientName"].ToString(),
                            IsVegan = (bool)reader["IsVegan"]
                        }
                    );
                }
            }

            return pizzas;
        }
    }

    public Pizza? Get(int id)
    {
        Pizza pizza = null;

        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();

            var sqlString = "SELECT P.Id AS PizzaId, P.Name AS PizzaName, P.IsGlutenFree, I.Id AS IngredientId, I.Name AS IngredientName, I.IsVegan FROM Pizza P JOIN PizzaIngredientes PI ON P.Id = PI.PizzaId JOIN Ingredientes I ON PI.IngredienteId = I.Id WHERE P.Id = " + id;
            var command = new SqlCommand(sqlString, connection);

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (pizza == null)
                    {
                        pizza = new Pizza
                        {
                            Id = (int)reader["PizzaId"],
                            Name = reader["PizzaName"].ToString(),
                            IsGlutenFree = (bool)reader["IsGlutenFree"],
                            Ingredients = new List<Ingredientes>()
                        };
                    }

                    pizza.Ingredients.Add(
                        new Ingredientes
                        {
                            Id = (int)reader["IngredientId"],
                            Name = reader["IngredientName"].ToString(),
                            IsVegan = (bool)reader["IsVegan"]
                        }
                    );
                }
            }

            return pizza;
        }
    }

    public List<Ingredientes>? GetIngredients(int id)
    {
        Pizza pizza = null;

        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();

            var sqlString = "SELECT I.Id AS IngredientId, I.Name AS IngredientName, I.IsVegan FROM PizzaIngredientes PI JOIN Ingredientes I ON PI.IngredienteId = I.Id WHERE PI.PizzaId = " + id;
            var command = new SqlCommand(sqlString, connection);

            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (pizza == null)
                    {
                        pizza = new Pizza
                        {
                            Id = (int)reader["PizzaId"],
                            Name = reader["PizzaName"].ToString(),
                            IsGlutenFree = (bool)reader["IsGlutenFree"],
                            Ingredients = new List<Ingredientes>()
                        };
                    }

                    pizza.Ingredients.Add(
                        new Ingredientes
                        {
                            Id = (int)reader["IngredientId"],
                            Name = reader["IngredientName"].ToString(),
                            IsVegan = (bool)reader["IsVegan"]
                        }
                    );
                }
            }

            return pizza.Ingredients;
        }
    }

    public void Add(Pizza pizza)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            string insertPizzaQuery = "INSERT INTO Pizza (Name, IsGlutenFree) VALUES (@Name, @IsGlutenFree); SELECT SCOPE_IDENTITY();";
            SqlCommand insertPizzaCommand = new SqlCommand(insertPizzaQuery, connection);
            insertPizzaCommand.Parameters.AddWithValue("@Name", pizza.Name);
            insertPizzaCommand.Parameters.AddWithValue("@IsGlutenFree", pizza.IsGlutenFree);
            int newPizzaId = Convert.ToInt32(insertPizzaCommand.ExecuteScalar());

            foreach (var ingredient in pizza.Ingredients)
            {
                string insertIngredientQuery = "IF NOT EXISTS (SELECT 1 FROM Ingredientes WHERE Name = @Name) " + "INSERT INTO Ingredientes (Name, IsVegan) VALUES (@Name, @IsVegan);";
                SqlCommand insertIngredientCommand = new SqlCommand(insertIngredientQuery, connection);
                insertIngredientCommand.Parameters.AddWithValue("@Name", ingredient.Name);
                insertIngredientCommand.Parameters.AddWithValue("@IsVegan", ingredient.IsVegan);
                insertIngredientCommand.ExecuteNonQuery();

                string getIngredientIdQuery = "SELECT Id FROM Ingredientes WHERE Name = @Name;";
                SqlCommand getIngredientIdCommand = new SqlCommand(getIngredientIdQuery, connection);
                getIngredientIdCommand.Parameters.AddWithValue("@Name", ingredient.Name);
                int ingredientId = Convert.ToInt32(getIngredientIdCommand.ExecuteScalar());

                string insertPizzaIngredientQuery = "INSERT INTO PizzaIngredientes (PizzaId, IngredienteId) VALUES (@PizzaId, @IngredientId);";
                SqlCommand insertPizzaIngredientCommand = new SqlCommand(insertPizzaIngredientQuery, connection);
                insertPizzaIngredientCommand.Parameters.AddWithValue("@PizzaId", newPizzaId);
                insertPizzaIngredientCommand.Parameters.AddWithValue("@IngredientId", ingredientId);
                insertPizzaIngredientCommand.ExecuteNonQuery();
            }
        }
    }

    public void Delete(int id)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            string deletePizzaIngredientesQuery = "DELETE FROM PizzaIngredientes WHERE PizzaId = @PizzaId";
            SqlCommand deletePizzaIngredientesCommand = new SqlCommand(deletePizzaIngredientesQuery, connection);
            deletePizzaIngredientesCommand.Parameters.AddWithValue("@PizzaId", id);
            int pizzaId = Convert.ToInt32(deletePizzaIngredientesCommand.ExecuteScalar());
            deletePizzaIngredientesCommand.ExecuteNonQuery();

            string deletePizzaQuery = "DELETE FROM Pizza WHERE Id = @Id";
            SqlCommand deletePizzaCommand = new SqlCommand(deletePizzaQuery, connection);
            deletePizzaCommand.Parameters.AddWithValue("@Id", id);
            deletePizzaCommand.ExecuteNonQuery();
        }
    }

    public void Update(int id, Pizza pizza)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            connection.Open();
            string updatePizzaQuery = "UPDATE Pizza SET Name = @Name, IsGlutenFree = @IsGlutenFree WHERE Id = @PizzaId;";
            SqlCommand updatePizzaCommand = new SqlCommand(updatePizzaQuery, connection);
            updatePizzaCommand.Parameters.AddWithValue("@PizzaId", id);
            updatePizzaCommand.Parameters.AddWithValue("@Name", pizza.Name);
            updatePizzaCommand.Parameters.AddWithValue("@IsGlutenFree", pizza.IsGlutenFree);
            updatePizzaCommand.ExecuteNonQuery();

            string deleteIngredientsQuery = "DELETE FROM PizzaIngredientes WHERE PizzaId = @PizzaId;";
            SqlCommand deleteIngredientsCommand = new SqlCommand(deleteIngredientsQuery, connection);
            deleteIngredientsCommand.Parameters.AddWithValue("@PizzaId", id);
            deleteIngredientsCommand.ExecuteNonQuery();

            foreach (var ingredient in pizza.Ingredients)
            {
                string insertIngredientQuery = "IF NOT EXISTS (SELECT 1 FROM Ingredientes WHERE Name = @Name) " + "INSERT INTO Ingredientes (Name, IsVegan) VALUES (@Name, @IsVegan);";
                SqlCommand insertIngredientCommand = new SqlCommand(insertIngredientQuery, connection);
                insertIngredientCommand.Parameters.AddWithValue("@Name", ingredient.Name);
                insertIngredientCommand.Parameters.AddWithValue("@IsVegan", ingredient.IsVegan);
                insertIngredientCommand.ExecuteNonQuery();

                string getIngredientIdQuery = "SELECT Id FROM Ingredientes WHERE Name = @Name;";
                SqlCommand getIngredientIdCommand = new SqlCommand(getIngredientIdQuery, connection);
                getIngredientIdCommand.Parameters.AddWithValue("@Name", ingredient.Name);
                int ingredientId = Convert.ToInt32(getIngredientIdCommand.ExecuteScalar());

                string insertPizzaIngredientQuery = "INSERT INTO PizzaIngredientes (PizzaId, IngredienteId) VALUES (@PizzaId, @IngredientId);";
                SqlCommand insertPizzaIngredientCommand = new SqlCommand(insertPizzaIngredientQuery, connection);
                insertPizzaIngredientCommand.Parameters.AddWithValue("@PizzaId", pizza.Id);
                insertPizzaIngredientCommand.Parameters.AddWithValue("@IngredientId", ingredientId);
                insertPizzaIngredientCommand.ExecuteNonQuery();
            }
        }
    }
}