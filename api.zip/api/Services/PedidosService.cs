using api.Data;
using api.Models;

namespace api.Services;

public class PedidosService : IPedidosService

{
    private readonly IPedidosData _ordersRepository;

    public PedidosService(IPedidosData ordersRepository)
    {
        _ordersRepository = ordersRepository;
    }

    public List<Pedidos> GetAll() => _ordersRepository.GetAll();

    public Pedidos? Get(int id) => _ordersRepository.Get(id);

    public List<Pizza>? GetPizzas(int id) => _ordersRepository.GetPizzas(id);

    public Usuarios? GetUsuarios(int id) => _ordersRepository.GetUsuarios(id);

    public void Add(Pedidos order) => _ordersRepository.Add(order);

    public void Update(Pedidos order) => _ordersRepository.Update(order);

    public void Delete(int id) => _ordersRepository.Delete(id);
}