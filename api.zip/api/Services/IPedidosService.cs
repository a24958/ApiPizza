using api.Models;

namespace api.Services;
public interface IPedidosService
{
    List<Pedidos> GetAll();
    Pedidos? Get(int id);
    List<Pizza>? GetPizzas(int id);
    Usuarios? GetUsuarios(int id);
    void Add(Pedidos order);
    void Delete(int id);
    void Update(Pedidos order);
}