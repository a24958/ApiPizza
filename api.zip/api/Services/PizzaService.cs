﻿using api.Data;
using api.Models;

namespace api.Services;

    public class PizzaService : IPizzaService
    {
        private readonly IPizzaData _pizzaRepository;

        public PizzaService(IPizzaData pizzaRepository)
        {
            _pizzaRepository = pizzaRepository;
        }

        public List<Pizza> GetAll() => _pizzaRepository.GetAll();

        public Pizza? Get(int id) => _pizzaRepository.Get(id);

        public List<Ingredientes>? GetIngredients(int id) => _pizzaRepository.GetIngredients(id);

        public void Add(Pizza pizza) => _pizzaRepository.Add(pizza);

        public void Update(int id, Pizza pizza) => _pizzaRepository.Update(id, pizza);

        public void Delete(int id) => _pizzaRepository.Delete(id);

}

