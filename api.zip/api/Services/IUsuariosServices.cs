using api.Models;

namespace api.Services;
public interface IUsuariosService
{
    List<Usuarios> GetAll();
    Usuarios? Get(int id);
    void Add(Usuarios user);
    void Delete(int id);
    void Update(Usuarios user);
}