using api.Data;
using api.Models;

namespace api.Services;

public class UsuariosService : IUsuariosService
{
    private readonly IUsusariosData _usersRepository;

    public UsuariosService(IUsusariosData usersRepository)
    {
        _usersRepository = usersRepository;
    }

    public List<Usuarios> GetAll() => _usersRepository.GetAll();

    public Usuarios? Get(int id) => _usersRepository.Get(id);

    public void Add(Usuarios user) => _usersRepository.Add(user);

    public void Update(Usuarios user) => _usersRepository.Update(user);

    public void Delete(int id) => _usersRepository.Delete(id);
}