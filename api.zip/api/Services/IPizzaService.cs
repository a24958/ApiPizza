using api.Models;

namespace api.Services;
public interface IPizzaService
{
    List<Pizza> GetAll();
    Pizza? Get(int id);
    List<Ingredientes>? GetIngredients(int id);
    void Add(Pizza pizza);
    void Delete(int id);
    void Update(int id, Pizza pizza);
}