using api.Data;
using api.Models;

namespace api.Services;

public class IngredientesService : IIngredientesService
{
    private readonly IIngredientesData _ingredientesRepository;

    public IngredientesService(IIngredientesData ingredientesRepository)
    {
        _ingredientesRepository = ingredientesRepository;
    }

    public List<Ingredientes> GetAll() => _ingredientesRepository.GetAll();

    public Ingredientes? Get(int id) => _ingredientesRepository.Get(id);

    public void Add(Ingredientes ingredient) => _ingredientesRepository.Add(ingredient);

    public void Update(Ingredientes ingredient) => _ingredientesRepository.Update(ingredient);

    public void Delete(int id) => _ingredientesRepository.Delete(id);
}