using api.Services;
using api.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

var connectionString = builder.Configuration.GetConnectionString("PizzaTeteDB");

builder.Services.AddSingleton<IPizzaService, PizzaService>();
// builder.Services.AddSingleton<IPizzaData, PizzaData>();
builder.Services.AddSingleton<IPizzaData, PizzaDataSQL>(serviceProvider => 
    new PizzaDataSQL(connectionString));

builder.Services.AddSingleton<IIngredientesService, IngredientesService>();
builder.Services.AddSingleton<IIngredientesData, IngredientesData>();

builder.Services.AddSingleton<IUsuariosService, UsuariosService>();
builder.Services.AddSingleton<IUsusariosData, UsuariosData>();

builder.Services.AddSingleton<IPedidosService, PedidosService>();
builder.Services.AddSingleton<IPedidosData, PedidosData>();


builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
