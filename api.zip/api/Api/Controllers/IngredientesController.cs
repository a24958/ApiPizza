using api.Models;
using api.Services;
using Microsoft.AspNetCore.Mvc;

namespace api.Api.Controllers;

[ApiController]
[Route("[controller]")]

public class IngredientesController : ControllerBase 
{
    private readonly IIngredientesService _ingredientesService;

    public IngredientesController(IIngredientesService ingredientesService)
    {
        _ingredientesService = ingredientesService;
    }

    [HttpGet]
    public ActionResult<List<Ingredientes>> GetAll() => _ingredientesService.GetAll();

    [HttpGet("{id}")]
    public ActionResult<Ingredientes> Get(int id)
    {
        var ingredient = _ingredientesService.Get(id);

        if (ingredient == null)
            return NotFound();

        return ingredient;
    }

    [HttpPost]
    public IActionResult Create(Ingredientes ingredient)
    {
        _ingredientesService.Add(ingredient);
        return CreatedAtAction(nameof(Get), new { id = ingredient.Id }, ingredient);
    }

    [HttpPut("{id}")]
    public IActionResult Update(int id, Ingredientes ingredient)
    {
        if (id != ingredient.Id)
            return BadRequest();

        var existingIngredient = _ingredientesService.Get(id);
        if (existingIngredient is null)
            return NotFound();

        _ingredientesService.Update(ingredient);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var ingredient = _ingredientesService.Get(id);

        if (ingredient is null)
            return NotFound();

        _ingredientesService.Delete(id);

        return NoContent();
    }
}