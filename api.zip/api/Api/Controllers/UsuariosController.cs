using api.Models;
using api.Services;
using Microsoft.AspNetCore.Mvc;

namespace api.Api.Controllers;

[ApiController]
[Route("[controller]")]

public class UsuariosController : ControllerBase 
{
    private readonly IUsuariosService _usuariosService;

    public UsuariosController(IUsuariosService usuariosService)
    {
        _usuariosService = usuariosService;
    }

    [HttpGet]
    public ActionResult<List<Usuarios>> GetAll() => _usuariosService.GetAll();

    [HttpGet("{id}")]
    public ActionResult<Usuarios> Get(int id)
    {
        var user = _usuariosService.Get(id);

        if (user == null)
            return NotFound();

        return user;
    }

    [HttpPost]
    public IActionResult Create(Usuarios user)
    {
        _usuariosService.Add(user);
        return CreatedAtAction(nameof(Get), new { id = user.Id }, user);
    }

    [HttpPut("{id}")]
    public IActionResult Update(int id, Usuarios user)
    {
        if (id != user.Id)
            return BadRequest();

        var existingUser = _usuariosService.Get(id);
        if (existingUser is null)
            return NotFound();

        _usuariosService.Update(user);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var user = _usuariosService.Get(id);

        if (user is null)
            return NotFound();

        _usuariosService.Delete(id);

        return NoContent();
    }
}