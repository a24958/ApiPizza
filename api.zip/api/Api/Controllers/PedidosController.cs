using api.Models;
using api.Services;
using Microsoft.AspNetCore.Mvc;

namespace api.Api.Controllers;

[ApiController]
[Route("[controller]")]

public class PedidosController : ControllerBase 
{
    private readonly IPedidosService _ordersService;

    public PedidosController(IPedidosService ordersService)
    {
        _ordersService = ordersService;
    }

    [HttpGet]
    public ActionResult<List<Pedidos>> GetAll() => _ordersService.GetAll();

    [HttpGet("{id}")]
    public ActionResult<Pedidos> Get(int id)
    {
        var order = _ordersService.Get(id);

        if (order == null)
            return NotFound();

        return order;
    }

    [HttpGet("{id}/Pizzas")]
    public ActionResult<List<Pizza>> GetPizzas(int id)
    {
        var order = _ordersService.Get(id);

        if(order == null)
        return NotFound();

        return order.Pizzas!;
    }

    [HttpGet("{id}/Usuario")]
    public ActionResult<Usuarios> GetUsuario(int id)
    {
        var order = _ordersService.Get(id);

        if(order == null)
        return NotFound();

        return order.User!;
    }

    [HttpPost]
    public IActionResult Create(Pedidos order)
    {
        _ordersService.Add(order);
        return CreatedAtAction(nameof(Get), new { id = order.Id }, order);
    }

    [HttpPut("{id}")]
    public IActionResult Update(int id, Pedidos order)
    {
        if (id != order.Id)
            return BadRequest();

        var existingOrder = _ordersService.Get(id);
        if (existingOrder is null)
            return NotFound();

        _ordersService.Update(order);

        return NoContent();
    }

    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        var order = _ordersService.Get(id);

        if (order is null)
            return NotFound();

        _ordersService.Delete(id);

        return NoContent();
    }
}